---
## Front matter
lang: ru-RU
title: Индивидуальный проект №5
author: |
	Баротов Комрон НБИ-01
institute: |
	\inst{1}RUDN University, Moscow, Russian Federation
	


## Formatting
toc: false
slide_level: 2
theme: metropolis
header-includes: 
 - \metroset{progressbar=frametitle,sectionpage=progressbar,numbering=fraction}
 - '\makeatletter'
 - '\beamer@ignorenonframefalse'
 - '\makeatother'
aspectratio: 43
section-titles: true
---

# Цель работы 

Добавление к сайту остальные элементы. Сделать запись для персональных проектов. Сделать пост по прошедшей недели. 

# Выполнение лабораторной работы

1. Написать о персональном проекте (рис. 1 )

![Редактирование шаблона ](images/1.png){ #fig:001 width=70% }

2. Написать пост о прошедшей недели (рис. 2 )

![Пост о прошедшей недели](images/2.png){ #fig:001 width=70% }

3. Написать пост по теме языки научного программирования (рис. 3 )

![Языки научного программирования](images/3.png){ #fig:001 width=70% }


# Выводы

В этом этапе мы добавили к нашему сайту остальные элементы. 



## {.standout}

Wer's nicht glaubt, bezahlt einen Taler
